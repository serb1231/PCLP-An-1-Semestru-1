typedef struct aa {
    char url[20];
    long int nr_accesari;
    long int checksum;
    char titlu[20];
    char *continut;
}site_continut;